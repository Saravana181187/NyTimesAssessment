//
//  ViewController.swift
//  NyTimesAssessment
//
//  Created by Saravanakumar B on 11/18/18.
//  Copyright © 2018 Saravanakumar B. All rights reserved.
//

import UIKit
import AFNetworking

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet weak var newsListTableView: UITableView!
    
    let apiKey:String = "47f57556a1f645c3a42487ba234b8752"
    var resultsArray = NSArray()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        newsListTableView.delegate = self
        newsListTableView.dataSource = self
        newsListTableView.tableFooterView = UIView()
        // Do any additional setup after loading the view, typically from a nib.
        getNYTimesDataApiCall()
    }
    
    // MARK: getNYTimesDataApiCall
    func getNYTimesDataApiCall() {
        var params = NSMutableDictionary()
        params = [
            "api-key": apiKey
        ]
        let manager = AFHTTPSessionManager()
        manager.responseSerializer.acceptableContentTypes = NSSet(array: ["text/plain", "text/html", "application/json"]) as Set<NSObject> as Set<NSObject>? as! Set<String>?
        let urlString:NSString = NSString(format: "%@%@", ApiConstantFile().baseUrlString,ApiConstantFile().accessUrlString)
        print(urlString)
        manager.get(urlString as String, parameters: params, progress: nil, success: {
            (operation, responseObject) in
            let responseDict:NSDictionary = responseObject as! NSDictionary
            print("responseDict is: ", responseDict)
            self.resultsArray = responseDict.value(forKey: "results") as! NSArray
            print("resultsArray is: ", self.resultsArray)
            DispatchQueue.main.async {
                self.newsListTableView.reloadData()
            }
        }, failure: {
            (operation, error) in
            print(error)
            self.alert(message: error.localizedDescription)
        })
    }
    
    //MARK: - TableView Delegate and Datasource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return resultsArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ListTableViewCell", for: indexPath) as! ListTableViewCell
        cell.titleLabel.text = (resultsArray[indexPath.row] as AnyObject).value(forKey: "title") as? String
        cell.authorLabel.text = (resultsArray[indexPath.row] as AnyObject).value(forKey: "byline") as? String
        cell.dateLabel.text = (resultsArray[indexPath.row] as AnyObject).value(forKey: "published_date") as? String
        
        let imageUrlArray: NSArray = ((((resultsArray[indexPath.row] as AnyObject).value(forKey: "media") as AnyObject).value(forKey: "media-metadata") as! NSArray)[0] as AnyObject).value(forKey: "url") as! NSArray
        print(imageUrlArray[0])
        
        cell.newsIconImageView.layer.cornerRadius =  37.0
        cell.newsIconImageView.clipsToBounds = true
        cell.newsIconImageView.layer.masksToBounds = true
        let URL_IMAGE = URL(string: imageUrlArray[0] as! String)
        cell.newsIconImageView.setImageWith(URL_IMAGE!)
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        print(indexPath.row)
        let DetailVC = self.storyboard?.instantiateViewController(withIdentifier: "DetailViewController") as? DetailViewController
        let imageUrlArray: NSArray = ((((resultsArray[indexPath.row] as AnyObject).value(forKey: "media") as AnyObject).value(forKey: "media-metadata") as! NSArray)[0] as AnyObject).value(forKey: "url") as! NSArray
        print(imageUrlArray[0])
        DetailVC?.getImageString = imageUrlArray[0] as! String
        DetailVC?.newsDescString = (resultsArray[indexPath.row] as AnyObject).value(forKey: "abstract") as! String
        self.navigationController?.pushViewController(DetailVC!, animated: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
extension UIViewController {
    func alert(message: String, title: String = "") {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alertController.view.tintColor = .black
        let OKAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(OKAction)
        self.present(alertController, animated: true, completion: nil)
    }
}

