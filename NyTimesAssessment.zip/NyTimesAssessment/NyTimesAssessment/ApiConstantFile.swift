//
//  ApiConstantFile.swift
//  NyTimesAssessment
//
//  Created by Saravanakumar B on 11/18/18.
//  Copyright © 2018 Saravanakumar B. All rights reserved.
//

import UIKit

class ApiConstantFile: NSObject {
    
    let baseUrlString:String = "https://api.nytimes.com/svc/"
    let accessUrlString:String = "mostpopular/v2/mostviewed/all-sections/7.json"

}
